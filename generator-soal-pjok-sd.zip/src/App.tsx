import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  AlignmentType, 
  Header, 
  Footer, 
  PageNumber, 
  Table, 
  TableRow, 
  TableCell, 
  WidthType,
  BorderStyle,
  LineRuleType
} from 'docx';
import { saveAs } from 'file-saver';
import { 
  ClipboardCheck, 
  Download, 
  Loader2, 
  CheckCircle2, 
  FileText, 
  Award, 
  BookOpen, 
  Clock, 
  Users, 
  Settings2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

interface QuestionOptions {
  label: string;
  text: string;
}

interface Question {
  id: string;
  type: 'PG' | 'PGK' | 'Menjodohkan' | 'Isian' | 'Uraian';
  question: string;
  options?: QuestionOptions[];
  correctAnswer: string | string[];
  analysis: string;
  imagePrompt?: string;
  matchingItems?: { left: string; right: string }[];
}

interface ExamData {
  title: string;
  subject: string;
  classLevel: string;
  fase: string;
  duration: string;
  teacherName: string;
  questions: Question[];
  schoolInfo: {
    pemda: string;
    dinas: string;
    instansi: string;
    jenisUjian: string;
    tahunPelajaran: string;
  };
}

// --- App Component ---

export default function App() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [examData, setExamData] = useState<ExamData | null>(null);

  // Form States
  const [fase, setFase] = useState('Fase C');
  const [grade, setGrade] = useState('Kelas 6');
  const [material, setMaterial] = useState('Gabungan Materi Semester 1 dan 2');
  const [hotsPercentage, setHotsPercentage] = useState(30);

  // Detail Question Counts
  const [countPG, setCountPG] = useState(15);
  const [countPGK, setCountPGK] = useState(10);
  const [countMatch, setCountMatch] = useState(5);
  const [countShort, setCountShort] = useState(5);
  const [countEssay, setCountEssay] = useState(5);

  const totalQuestions = countPG + countPGK + countMatch + countShort + countEssay;

  // School Info States
  const [schoolInfo, setSchoolInfo] = useState({
    pemda: 'PEMERINTAH KABUPATEN PROBOLINGGO',
    dinas: 'DINAS PENDIDIKAN DAN KEBUDAYAAN',
    instansi: 'SD Negeri Negororejo II',
    jenisUjian: 'SUMATIF AKHIR SEMESTER 2',
    tahunPelajaran: '2025 / 2026',
  });

  const generateExam = async () => {
    setLoading(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const prompt = `
        Role: Anda adalah pakar kurikulum PJOK Sekolah Dasar yang sangat ahli dalam menyusun soal berdasarkan Kurikulum Merdeka.
        
        Buat set soal ujian PJOK dengan detail berikut:
        - Fase/Kelas: ${fase} / ${grade}
        - Materi: ${material}
        - Total Jumlah Soal: ${totalQuestions}
        - Komposisi Tipe Soal: 
           * Pilihan Ganda: ${countPG} soal
           * Pilihan Ganda Kompleks: ${countPGK} soal
           * Menjodohkan: ${countMatch} soal
           * Isian Singkat: ${countShort} soal
           * Uraian: ${countEssay} soal
        - Tingkat Kesulitan: ${hotsPercentage}% HOTS, Sisanya LOTS/MOTS.
        
        Instruksi Khusus:
        1. Berdasarkan Capaian Pembelajaran (CP) elemen Pengetahuan Gerak dan Pemanfaatan Gerak.
        2. Gunakan bahasa yang mudah dipahami anak SD namun tetap teknis secara olahraga.
        3. Untuk soal HOTS, berikan narasi kasus (misal: "Jika saat mendarat tangan jatuh ke belakang...").
        4. Sertakan Kunci Jawaban dan Analisis Jawaban (Penjelasan singkat kenapa jawaban itu benar).
        5. Jika soal menggunakan gambar buatkan promt dari gambar tersebut pada field imagePrompt.
        6. PG Kompleks sertakan pilihan jawaban seperti PG (multi-pilihan).
        7. Menjodohkan: Berikan ${countMatch} pasangan di matchingItems (left: pernyataan, right: jawaban). 
        8. Format Kunci Jawaban Menjodohkan: "a-3, b-1, c-5, d-2, e-4" (sesuaikan dengan urutan huruf di kiri dan angka di kanan).
        9. Pastikan urutan pertanyaan dikelompokkan berdasarkan tipe (PG dulu, lalu PGK, dst).
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    type: { type: Type.STRING, enum: ['PG', 'PGK', 'Menjodohkan', 'Isian', 'Uraian'] },
                    question: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          label: { type: Type.STRING },
                          text: { type: Type.STRING }
                        }
                      }
                    },
                    correctAnswer: { type: Type.STRING },
                    analysis: { type: Type.STRING },
                    imagePrompt: { type: Type.STRING },
                    matchingItems: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          left: { type: Type.STRING },
                          right: { type: Type.STRING }
                        }
                      }
                    }
                  },
                  required: ['id', 'type', 'question', 'correctAnswer', 'analysis']
                }
              }
            }
          }
        }
      });

      const result = JSON.parse(response.text || '{}');
      
      setExamData({
        title: schoolInfo.jenisUjian,
        subject: 'PJOK',
        classLevel: grade,
        fase: fase,
        duration: '90 Menit',
        teacherName: '', 
        questions: result.questions,
        schoolInfo: schoolInfo
      });

    } catch (err) {
      console.error(err);
      setError('Gagal membuat soal. Pastikan API Key sudah terkonfigurasi dengan benar.');
    } finally {
      setLoading(false);
    }
  };

  const downloadWord = async () => {
    if (!examData) return;

    const isFaseA = examData.fase.includes('Fase A');
    const fontSize = isFaseA ? 28 : 24; // docx uses half-points (14pt = 28, 12pt = 24)
    const fontFamily = isFaseA ? 'Arial' : 'Times New Roman';
    const lineSpacing = isFaseA ? 480 : 360; // 240 is 1.0, so 480 is 2.0, 360 is 1.5
    
    // Header (KOP)
    const kopParagraphs = [
      new Paragraph({
        children: [new TextRun({ text: examData.schoolInfo.pemda.toUpperCase(), bold: true, size: fontSize + 2, font: fontFamily })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0 }
      }),
      new Paragraph({
        children: [new TextRun({ text: examData.schoolInfo.dinas.toUpperCase(), bold: true, size: fontSize + 2, font: fontFamily })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0 }
      }),
      new Paragraph({
        children: [new TextRun({ text: examData.schoolInfo.instansi.toUpperCase(), bold: true, size: fontSize + 4, font: fontFamily })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0 }
      }),
      new Paragraph({
        children: [new TextRun({ text: `TAHUN PELAJARAN ${examData.schoolInfo.tahunPelajaran}`, bold: true, size: fontSize, font: fontFamily })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0 }
      }),
      new Paragraph({
        border: { bottom: { color: "auto", space: 1, style: BorderStyle.SINGLE, size: 6 } },
        children: [],
        spacing: { before: 0, after: 0 }
      })
    ];

    // Exam Title
    const titleSection = new Paragraph({
      children: [new TextRun({ text: examData.schoolInfo.jenisUjian, bold: true, size: fontSize, font: fontFamily })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 200, after: 200 }, // Keep some rhythm for title
    });

    // Biodata Table (Flexible formatting based on instructions)
    const biodataTable = new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
        insideHorizontal: { style: BorderStyle.NONE },
        insideVertical: { style: BorderStyle.NONE },
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "Nama", font: fontFamily, size: fontSize })] })],
              width: { size: 15, type: WidthType.PERCENTAGE },
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: ": ...............................", font: fontFamily, size: fontSize })] })],
              width: { size: 35, type: WidthType.PERCENTAGE },
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "Mata Pelajaran", font: fontFamily, size: fontSize })] })],
              width: { size: 20, type: WidthType.PERCENTAGE },
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: ": PJOK", font: fontFamily, size: fontSize })] })],
              width: { size: 30, type: WidthType.PERCENTAGE },
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "No Presensi", font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: ": ...............................", font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "Waktu", font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: ": 90 Menit", font: fontFamily, size: fontSize })] })],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "Fase / Kelas", font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: `: ${examData.fase} / ${examData.classLevel}`, font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: "Nilai", font: fontFamily, size: fontSize })] })],
            }),
            new TableCell({
              children: [new Paragraph({ children: [new TextRun({ text: ": ...............................", font: fontFamily, size: fontSize })] })],
            }),
          ],
        }),
      ],
    });

    // --- Process Questions ---
    const questionSections: Paragraph[] = [];
    
    // Group by types
    const typesOrder = ['PG', 'PGK', 'Menjodohkan', 'Isian', 'Uraian'];
    const typeLabelMap: Record<string, string> = {
      PG: 'I. PILIHAN GANDA',
      PGK: 'II. PILIHAN GANDA KOMPLEKS',
      Menjodohkan: 'III. MENJODOHKAN',
      Isian: 'IV. ISIAN SINGKAT',
      Uraian: 'V. URAIAN'
    };

    const typeInstructionMap: Record<string, string> = {
      PG: 'Berilah tanda silang (X) pada huruf A, B, C, atau D pada jawaban yang paling benar!',
      PGK: 'Pilihlah satu atau lebih jawaban yang menurutmu benar dengan memberi tanda centang (√)!',
      Menjodohkan: 'Jodohkanlah pernyataan pada kolom A dengan jawaban yang tepat pada kolom B!',
      Isian: 'Isilah titik-titik di bawah ini dengan jawaban yang benar!',
      Uraian: 'Jawablah pertanyaan-pertanyaan di bawah ini dengan benar!'
    };

    typesOrder.forEach((type, idx) => {
      const typeQuestions = examData.questions.filter(q => q.type === type);
      if (typeQuestions.length === 0) return;

      questionSections.push(new Paragraph({
        children: [new TextRun({ text: typeLabelMap[type], bold: true, size: fontSize, font: fontFamily })],
        spacing: { before: 400, after: 100 },
      }));

      questionSections.push(new Paragraph({
        children: [new TextRun({ text: typeInstructionMap[type], italics: true, size: fontSize - 2, font: fontFamily })],
        spacing: { after: 200 },
      }));

      typeQuestions.forEach((q, qIdx) => {
        // Question text
        questionSections.push(new Paragraph({
          children: [new TextRun({ text: `${qIdx + 1}. ${q.question}`, size: fontSize, font: fontFamily })],
          spacing: { line: lineSpacing, before: 0, after: 0 },
        }));

        // Illustration/Prompt if any
        if (q.imagePrompt) {
          questionSections.push(new Paragraph({
            children: [new TextRun({ text: `(Ilustrasi Gambar: ${q.imagePrompt})`, italics: true, size: fontSize - 4, font: fontFamily, color: "666666" })],
            spacing: { before: 0, after: 0 },
          }));
        }

        // Options for PG and PGK
        if (q.options && (q.type === 'PG' || q.type === 'PGK')) {
          q.options.forEach(opt => {
            questionSections.push(new Paragraph({
              children: [new TextRun({ text: `   ${opt.label}. ${opt.text}`, size: fontSize, font: fontFamily })],
              spacing: { line: lineSpacing, before: 0, after: 0 },
              indent: { left: 720 },
            }));
          });
        }

        // Matching Items (Randomized layout as requested)
        if (q.type === 'Menjodohkan' && q.matchingItems) {
            // Shuffle rights for randomization
            const lefts = q.matchingItems.map(i => i.left);
            const rights = q.matchingItems.map(i => i.right).sort(() => Math.random() - 0.5);
            
    const rows = lefts.map((left, i) => {
        // Find which index in original rights this one is at
        const originalRightIndex = rights.indexOf(q.matchingItems![i].right);
        return new TableRow({
            children: [
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: `${String.fromCharCode(97 + i)}. ${left}`, size: fontSize, font: fontFamily })], spacing: { before: 0, after: 0 } })] }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: `[ ... ]`, size: fontSize, font: fontFamily })], alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 } })] }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: `${i + 1}. ${rights[i]}`, size: fontSize, font: fontFamily })], spacing: { before: 0, after: 0 } })] }),
            ]
        });
    });

    questionSections.push(new Paragraph({ children: [], spacing: { before: 0, after: 0 } }));
    const matchTable = new Table({
        rows,
        width: { size: 100, type: WidthType.PERCENTAGE },
        borders: {
            top: { style: BorderStyle.SINGLE },
            bottom: { style: BorderStyle.SINGLE },
            left: { style: BorderStyle.SINGLE },
            right: { style: BorderStyle.SINGLE },
            insideHorizontal: { style: BorderStyle.SINGLE },
            insideVertical: { style: BorderStyle.SINGLE },
        }
    });
            // @ts-ignore
            questionSections.push(matchTable);
            questionSections.push(new Paragraph({ children: [], spacing: { after: 200 } }));
        }

        // Spacing between questions
        questionSections.push(new Paragraph({ children: [], spacing: { after: 200 } }));
      });
    });

    // --- Answer Keys Section (Separated) ---
    const answerSections: Paragraph[] = [
      new Paragraph({
        children: [new TextRun({ text: "KUNCI JAWABAN DAN ANALISIS", bold: true, size: fontSize + 2, font: fontFamily })],
        alignment: AlignmentType.CENTER,
        spacing: { before: 800, after: 400 },
        pageBreakBefore: true,
      })
    ];

    examData.questions.forEach((q, idx) => {
      answerSections.push(new Paragraph({
        children: [
          new TextRun({ text: `${idx + 1}. Kunci: `, bold: true, size: fontSize, font: fontFamily }),
          new TextRun({ text: Array.isArray(q.correctAnswer) ? q.correctAnswer.join(', ') : q.correctAnswer, size: fontSize, font: fontFamily }),
        ],
        spacing: { line: lineSpacing },
      }));
      answerSections.push(new Paragraph({
        children: [
          new TextRun({ text: `   Analisis: `, italics: true, bold: true, size: fontSize, font: fontFamily }),
          new TextRun({ text: q.analysis, size: fontSize, font: fontFamily }),
        ],
        spacing: { line: lineSpacing, after: 200 },
        indent: { left: 360 },
      }));
    });

    // Create the document
    const doc = new Document({
      sections: [
        {
          properties: {
             // F4 size is approx 215.9 x 330.2 mm
             page: {
                size: {
                    width: "21.59cm",
                    height: "33cm",
                },
                margin: {
                    top: "1cm",
                    bottom: "1cm",
                    left: "1cm",
                    right: "1cm",
                }
             }
          },
          headers: {
            default: new Header({ children: [] }),
          },
          footers: {
            default: new Footer({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({ children: ["Halaman ", PageNumber.CURRENT, " dari ", PageNumber.TOTAL_PAGES], size: 20, font: fontFamily })
                  ],
                  alignment: AlignmentType.RIGHT,
                }),
              ],
            }),
          },
          children: [
            ...kopParagraphs,
            titleSection,
            biodataTable,
            new Paragraph({ children: [], spacing: { after: 400 } }),
            ...questionSections,
            ...answerSections
          ],
        },
      ],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Soal_PJOK_${examData.classLevel}_${examData.schoolInfo.jenisUjian.replace(/\s+/g, '_')}.docx`);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-[#FF6321]/20 overflow-x-hidden">
      {/* Decorative Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#FF6321]/5 blur-[120px] rounded-full" />
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-blue-500/5 blur-[100px] rounded-full" />
      </div>

      {/* Header */}
      <header className="border-b border-black/5 bg-white/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <motion.div 
              whileHover={{ rotate: 10 }}
              className="w-12 h-12 bg-gradient-to-br from-[#FF6321] to-[#FF8C5A] rounded-2xl flex items-center justify-center shadow-xl shadow-[#FF6321]/20"
            >
              <Award className="text-white w-7 h-7" />
            </motion.div>
            <div>
              <h1 className="font-extrabold text-2xl tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-black to-black/60">PJOK AI Pro</h1>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <p className="text-[10px] text-[#1A1A1A]/40 font-bold uppercase tracking-widest">KUMER Engine v2.0</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex flex-col items-end px-4 border-r border-black/5">
              <span className="text-[10px] font-bold text-black/40 uppercase">Total Soal</span>
              <span className="text-xl font-black text-[#FF6321] leading-none">{totalQuestions}</span>
            </div>
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={generateExam}
              disabled={loading}
              className="flex items-center gap-2 bg-[#1A1A1A] text-white px-6 py-3 rounded-2xl font-bold transition-all disabled:opacity-50 shadow-2xl shadow-black/20"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ClipboardCheck className="w-5 h-5" />}
              Generate Exam
            </motion.button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Sidebar Layout */}
          <div className="lg:col-span-4 space-y-8">
            {/* School Info (Header Dokumen) - Now first */}
            <div className="bg-[#1A1A1A] rounded-[32px] p-8 text-white shadow-2xl shadow-[#1A1A1A]/40 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF6321]/20 blur-3xl -mr-16 -mt-16 group-hover:bg-[#FF6321]/30 transition-all" />
              <div className="flex items-center gap-3 mb-8 relative z-10">
                <FileText className="w-5 h-5 text-[#FF6321]" />
                <h2 className="font-black text-lg tracking-tight">Header Dokumen</h2>
              </div>
              <div className="space-y-4 relative z-10">
                {Object.entries(schoolInfo).map(([key, value]) => (
                  <div key={key}>
                    <label className="block text-[9px] font-black uppercase opacity-30 mb-1.5 ml-1">{key.replace(/([A-Z])/g, ' $1')}</label>
                    <input 
                      type="text"
                      value={value}
                      onChange={(e) => setSchoolInfo({...schoolInfo, [key]: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold focus:ring-1 focus:ring-[#FF6321] focus:bg-white/10 transition-all outline-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Class & Subject Info (Pengaturan Utama) */}
            <div className="bg-white/70 backdrop-blur-md rounded-[32px] p-8 border border-white/20 shadow-2xl shadow-black/5">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Settings2 className="w-4 h-4 text-blue-600" />
                </div>
                <h2 className="font-black text-lg tracking-tight">Pengaturan Utama</h2>
              </div>
              
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-black/30 ml-2">Fase</label>
                    <select 
                      value={fase} 
                      onChange={(e) => setFase(e.target.value)}
                      className="w-full bg-black/5 border-none rounded-2xl px-4 py-3.5 text-sm font-bold focus:ring-2 focus:ring-[#FF6321] appearance-none transition-all"
                    >
                      <option>Fase A</option>
                      <option>Fase B</option>
                      <option>Fase C</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-black/30 ml-2">Kelas</label>
                    <select 
                      value={grade} 
                      onChange={(e) => setGrade(e.target.value)}
                      className="w-full bg-black/5 border-none rounded-2xl px-4 py-3.5 text-sm font-bold focus:ring-2 focus:ring-[#FF6321] appearance-none transition-all"
                    >
                      <option>Kelas 1</option>
                      <option>Kelas 2</option>
                      <option>Kelas 3</option>
                      <option>Kelas 4</option>
                      <option>Kelas 5</option>
                      <option>Kelas 6</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-black/30 ml-2">Materi Kumulatif</label>
                  <textarea 
                    value={material}
                    onChange={(e) => setMaterial(e.target.value)}
                    className="w-full bg-black/5 border-none rounded-2xl px-4 py-4 text-sm font-medium min-h-[100px] focus:ring-2 focus:ring-[#FF6321] transition-all resize-none"
                    placeholder="Contoh: Gabungan Materi Semester 1 dan 2..."
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center ml-2">
                    <label className="text-[10px] font-black uppercase text-black/30">Target HOTS</label>
                    <span className="text-xs font-black text-[#FF6321]">{hotsPercentage}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    value={hotsPercentage}
                    onChange={(e) => setHotsPercentage(Number(e.target.value))}
                    className="w-full accent-[#FF6321] h-2 bg-black/5 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Detailed Question Counts (Detail Tipe Soal) */}
            <div className="bg-white rounded-[32px] p-8 border border-black/5 shadow-2xl shadow-black/5">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-lg bg-[#FF6321]/10 flex items-center justify-center">
                  <ClipboardCheck className="w-4 h-4 text-[#FF6321]" />
                </div>
                <h2 className="font-black text-lg tracking-tight">Detail Tipe Soal</h2>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                {[
                  { label: 'Pilihan Ganda', val: countPG, setter: setCountPG, icon: 'PG' },
                  { label: 'PG Kompleks', val: countPGK, setter: setCountPGK, icon: 'PK' },
                  { label: 'Menjodohkan', val: countMatch, setter: setCountMatch, icon: 'MJ' },
                  { label: 'Isian Singkat', val: countShort, setter: setCountShort, icon: 'IS' },
                  { label: 'Uraian', val: countEssay, setter: setCountEssay, icon: 'UR' },
                ].map((item) => (
                  <div key={item.label} className="group flex items-center justify-between bg-black/5 hover:bg-black/[0.08] p-4 rounded-2xl transition-all">
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-[10px] font-black text-black/30 shadow-sm border border-black/5 group-hover:text-[#FF6321] transition-colors">{item.icon}</span>
                      <span className="text-sm font-bold text-black/70">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <button onClick={() => item.setter(Math.max(0, item.val - 1))} className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-lg font-black hover:bg-[#FF6321] hover:text-white transition-all shadow-sm">-</button>
                       <input 
                         type="number" 
                         value={item.val} 
                         onChange={(e) => item.setter(Number(e.target.value))}
                         className="w-12 text-center bg-transparent border-none font-black text-sm focus:ring-0"
                       />
                       <button onClick={() => item.setter(item.val + 1)} className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-lg font-black hover:bg-blue-500 hover:text-white transition-all shadow-sm">+</button>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Total Questions Summary */}
              <div className="mt-6 pt-6 border-t border-black/5">
                <div className="flex items-center justify-between bg-gradient-to-r from-[#FF6321] to-[#FF8C5A] p-5 rounded-2xl shadow-xl shadow-[#FF6321]/20">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                      <FileText className="text-white w-5 h-5" />
                    </div>
                    <span className="text-xs font-black text-white uppercase tracking-widest">Total Soal</span>
                  </div>
                  <span className="text-3xl font-black text-white leading-none">{totalQuestions}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              {!examData && !loading && (
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-[48px] p-16 text-center h-full flex flex-col items-center justify-center border border-black/5 shadow-2xl shadow-black/5"
                >
                  <div className="relative mb-8">
                    <motion.div 
                      animate={{ 
                        scale: [1, 1.05, 1],
                        rotate: [0, 5, 0, -5, 0]
                      }}
                      transition={{ duration: 6, repeat: Infinity }}
                      className="w-28 h-28 bg-gradient-to-tr from-[#FF6321]/10 to-blue-500/10 rounded-full flex items-center justify-center shadow-inner"
                    >
                      <BookOpen className="w-12 h-12 text-[#FF6321]" />
                    </motion.div>
                  </div>
                  <h3 className="text-4xl font-black mb-4 tracking-tighter">AI Exam Engine</h3>
                  <p className="text-[#1A1A1A]/40 max-w-sm mx-auto mb-10 font-medium leading-relaxed">
                    Sistem cerdas berbasis Kurikulum Merdeka Fase A-C. Cukup klik satu tombol untuk mendapatkan soal berkualitas tinggi.
                  </p>
                  <motion.button 
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={generateExam}
                    className="flex items-center gap-3 bg-[#FF6321] text-white px-10 py-5 rounded-[24px] font-black text-lg shadow-2xl shadow-[#FF6321]/30"
                  >
                    Mulai Generate
                  </motion.button>
                </motion.div>
              )}

              {loading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center h-[700px] text-center"
                >
                  <div className="relative">
                    <div className="w-24 h-24 border-4 border-[#FF6321]/20 border-t-[#FF6321] rounded-full animate-spin" />
                    <motion.div 
                      animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.3, 0.6, 0.3] }} 
                      transition={{ repeat: Infinity, duration: 2.5 }}
                      className="absolute inset-0 bg-[#FF6321] blur-3xl rounded-full"
                    />
                  </div>
                  <h3 className="text-2xl font-black mt-10 mb-2 tracking-tight">Merakit Soal PJOK...</h3>
                  <p className="text-[#1A1A1A]/40 font-bold uppercase tracking-[0.2em] text-[10px]">Processing Kurikulum Merdeka Database</p>
                </motion.div>
              )}

              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-10 bg-red-50 rounded-[32px] border border-red-100 flex flex-col items-center text-center gap-4 text-red-600"
                >
                  <div className="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center">
                    <AlertCircle className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black mb-1">Gagal Terhubung</h4>
                    <p className="text-sm font-medium opacity-70">{error}</p>
                    <button onClick={generateExam} className="mt-6 px-6 py-2 bg-red-600 text-white rounded-full font-bold text-sm shadow-lg shadow-red-200">Coba Lagi</button>
                  </div>
                </motion.div>
              )}

              {examData && !loading && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-8"
                >
                  <div className="bg-[#1A1A1A] rounded-[32px] p-8 border border-white/10 shadow-2xl shadow-black/20 flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-5">
                      <div className="w-16 h-16 bg-green-500/10 rounded-[20px] flex items-center justify-center border border-green-500/20">
                        <CheckCircle2 className="text-green-500 w-9 h-9" />
                      </div>
                      <div>
                        <h3 className="font-black text-2xl text-white tracking-tight">Generasi Selesai</h3>
                        <p className="text-sm font-bold text-white/40 uppercase tracking-widest">{examData.questions.length} Butir Soal Verifikasi AI</p>
                      </div>
                    </div>
                    
                    <motion.button 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={downloadWord}
                      className="flex items-center gap-3 bg-white text-black px-8 py-4 rounded-[20px] font-black shadow-xl hover:bg-white/90 transition-all whitespace-nowrap"
                    >
                      <Download className="w-5 h-5 text-[#FF6321]" />
                      Download Word
                    </motion.button>
                  </div>

                  <div className="bg-white rounded-[48px] border border-black/5 overflow-hidden shadow-2xl shadow-black/5">
                    <div className="bg-gradient-to-br from-white to-[#F5F5F0] p-10 border-b border-black/5 relative overflow-hidden">
                       <div className="absolute top-0 right-0 p-8 opacity-5 font-black text-8xl tracking-tighter select-none">PJOK</div>
                      <h4 className="font-black uppercase tracking-[0.4em] text-[10px] text-black/30 mb-4">Preview Draft Ujian</h4>
                      <h2 className="text-3xl font-black tracking-tighter mb-6">{examData.schoolInfo.instansi}</h2>
                      <div className="flex flex-wrap gap-3">
                        <div className="flex items-center gap-2 text-xs font-black bg-white px-4 py-2 rounded-2xl border border-black/5 shadow-sm">
                          <Clock className="w-3.5 h-3.5 text-[#FF6321]" />
                          90 Menit
                        </div>
                        <div className="flex items-center gap-2 text-xs font-black bg-white px-4 py-2 rounded-2xl border border-black/5 shadow-sm uppercase tracking-wider">
                          <Users className="w-3.5 h-3.5 text-blue-500" />
                          {examData.fase} / {examData.classLevel}
                        </div>
                        <div className="flex items-center gap-2 text-xs font-black bg-[#FF6321] text-white px-4 py-2 rounded-2xl shadow-lg shadow-[#FF6321]/20">
                          {examData.questions.length} Soal
                        </div>
                      </div>
                    </div>

                    <div className="p-10 space-y-12 max-h-[1000px] overflow-y-auto custom-scrollbar bg-white">
                      {examData.questions.map((q, idx) => (
                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          key={q.id} 
                          className="group relative"
                        >
                          <div className="absolute -left-8 top-0 text-[56px] font-black text-black/[0.03] leading-none group-hover:text-[#FF6321]/5 transition-colors pointer-events-none">
                            {String(idx + 1).padStart(2, '0')}
                          </div>
                          <div className="pl-10">
                            <div className="flex items-center gap-2 mb-4">
                              <span className="inline-block px-3 py-1 bg-black text-white text-[9px] font-black rounded-lg uppercase tracking-widest">{q.type}</span>
                              {q.imagePrompt && <span className="px-3 py-1 bg-blue-500/10 text-blue-600 text-[9px] font-black rounded-lg uppercase tracking-widest">Ilustrasi</span>}
                            </div>
                            <p className="font-bold text-xl mb-6 text-black leading-tight group-hover:text-[#FF6321] transition-colors">
                              {q.question}
                            </p>
                            
                            {q.options && (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                                {q.options.map(opt => (
                                  <div key={opt.label} className="group/opt bg-[#F8F9FA] hover:bg-white p-5 rounded-[24px] flex items-start gap-4 border border-transparent hover:border-[#FF6321]/30 hover:shadow-xl hover:shadow-[#FF6321]/5 transition-all">
                                    <span className="w-8 h-8 shrink-0 bg-white rounded-xl flex items-center justify-center font-black text-sm shadow-sm border border-black/5 group-hover/opt:bg-[#FF6321] group-hover/opt:text-white transition-all">{opt.label}</span>
                                    <span className="text-sm font-bold text-black/70 mt-1">{opt.text}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {q.matchingItems && (
                                <div className="mt-6 p-6 bg-[#F8F9FA] rounded-[32px] border border-black/5">
                                    <p className="text-[10px] font-black uppercase text-black/30 mb-4">Konten Menjodohkan</p>
                                    <div className="grid grid-cols-2 gap-4 text-sm font-bold opacity-60">
                                        <ul className="space-y-2">
                                            {q.matchingItems.map((mi, i) => <li key={i}>{String.fromCharCode(97+i)}. {mi.left}</li>)}
                                        </ul>
                                        <ul className="space-y-2">
                                            {q.matchingItems.map((mi, i) => <li key={i}>{i+1}. {mi.right}</li>)}
                                        </ul>
                                    </div>
                                </div>
                            )}

                            <div className="mt-8 p-6 rounded-[28px] bg-gradient-to-br from-orange-50 to-white border border-orange-100 flex items-start gap-4 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-2 group-hover:translate-y-0">
                              <div className="w-10 h-10 bg-[#FF6321]/10 rounded-full flex items-center justify-center shrink-0">
                                <CheckCircle2 className="w-5 h-5 text-[#FF6321]" />
                              </div>
                              <div>
                                <p className="text-[10px] font-black text-[#FF6321] uppercase tracking-widest mb-1.5">Kunci & Analisis Jawaban</p>
                                <p className="text-sm font-bold text-black/80 leading-relaxed">{q.analysis}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #1A1A1A10;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #1A1A1A20;
        }
      `}</style>
    </div>
  );
}
